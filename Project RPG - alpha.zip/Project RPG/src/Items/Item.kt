package Items

open class Item(var name: String) {

open fun tankWahl(){

}

}
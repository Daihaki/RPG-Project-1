package Items

import Hero.Hero

class Traenke(name: String) : Item(name) {


    fun beutel() {


    }


    fun heiltrank(hero: Hero) {

        var hp = hero.lifePoints
        var heal = hp * 0.5

        hero.lifePoints += heal.toInt()
        if (hero.lifePoints >= heal) {
            println("das ist nicht möglich, dein Held hat zu viel Lebenspunkte.")
        }
    }

    open fun manatrank(hero: Hero) {

        var maxHp = hero.lifePoints
        var halfLife = maxHp * 0.5

        hero.lifePoints += halfLife.toInt()
        if (hero.lifePoints >= halfLife) {
            println("das ist nicht möglich, dein Held hat zu viel Lebenspunkte.")
        }
    }

    open fun powertrank(hero: Hero) {

        var powerPlus = 1.20
        var newDmg = powerPlus + hero.lifePoints

    }

    fun trankWahl(item: Item, hero: Hero) {
        println("Wähle deinen Trank.")
        println("1 -> Heil-trank")
        println("2 -> Mana-trank")
        println("3 -> Power-trank")

        var auswahl = readln().toInt()

        when (auswahl) {
            1 -> heiltrank(hero)
            2 -> manatrank(hero)
            3 -> powertrank(hero)
        }

    }
}